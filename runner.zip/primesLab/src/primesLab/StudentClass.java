package primesLab;

import java.util.Arrays;

public class StudentClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//setup the test
		int size = 100;
		
		boolean[] primes = new boolean[size];
		
		//test how long it takes
		long startTime = System.nanoTime();
		generatePrimes(primes); //calculate the prime #s
		
		//done generating, what's the total time?
		System.out.println(System.nanoTime() - startTime);
		
		System.out.println(Arrays.toString(primes));
		for(int i = 0; i < primes.length; i++) {
			if(primes[i]) {
				System.out.println(i+1);
			}
		}
		
	}
	
	//generatePrimes method
	public static void generatePrimes(boolean[] nums) {
		//1) mark every value in nums as a prime
		//aka assume every # is a prime
		//traverse the array - set every element to true
		for(int i = 0; i < nums.length; i++) {
			nums[i] = true;
		}
		
		for(int m = 2; m < nums.length; m++) {
			for(int i = m; i < nums.length; i++) {
				
				//check if the number at index i represents
				//a number that is a multiple of m
				if((i + 1) % m == 0) {
						nums[i] = false;
						
					
				}
				
				
			}

		}
		
		
		
	}

}
