
public class Person {
	
	//attributes - instance variables
	//they exist as long as an object of this type exists
	private String name;
	private int age;
	
	//static variables
	//properties of the CLASS
	public static int population = 0;
	
	//add a default constructor
	public Person() {
		
		//init the attributes
		this.name = "John Smith";
		this.age = 1;
		population += 1;
		
	}
	
	//add the 2 getters for age and name
	//accessor
	public String getName() {
		return this.name;
	}
	
	public int getAge() {
		return this.age;
	}
	
	/*
	 * public varType getVarName(){
	 * 		return varName;
	 * 
	 * }
	 */
	
	//add the 2 setters for age and name
	//mutator
	/*
	 * public void setVarName(varType newValue){
	 * 		varName = newValue;
	 * }
	 */
	
	//age
	public void setAge(int newValue) {
		this.age = newValue;
	}
	
	public void setName(String newValue) {
		this.name = newValue;
	}
	
	//static methods - helper methods of the class
	//associated with the Class, not objects
	public static void hello() {
		System.out.println("hello");
		
		//static methods exist without objects
		//thus they cannot access INSTANCE variables
		//or instance methods because those require an object
		//to exist
		
	}
}
