
public class Runner {

	public static void main(String[] args) {
		
		System.out.println(Person.population);
		
		Person personA = new Person();
		System.out.println(personA.getName());
		personA.setName("Billy Bob");
		System.out.println(personA.getName());
		
		Person personB = new Person();
		Person personC = new Person();
		Person personD = new Person();
		Person personE = new Person();
		
		System.out.println(Person.population);
		
		
		System.out.println(Math.PI);
		System.out.println(Math.sqrt(4));

	}

}
