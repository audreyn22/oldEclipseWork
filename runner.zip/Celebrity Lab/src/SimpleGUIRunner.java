import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToggleButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class SimpleGUIRunner
{
	public static void main(String[] args)
	{
		JFrame sample = new JFrame();
		sample.setSize(800, 600); //set size
		
		//set a layout manager by default to try to add
		//components that are not on top of each other
		sample.setLayout(new FlowLayout());
		
		
		sample.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //connect x button to exit program
		
		//^^ without the line above, program will run even if JFrame is closed
		
		JButton myButton = new JButton("Start");
		myButton.setPreferredSize(new Dimension(100, 25));
		myButton.setBackground(new Color(255, 215, 0));
		//add a component to the JFrame
		sample.add(myButton);
		
		JRadioButton myRButton = new JRadioButton("Click here!");
		sample.add(myRButton);
		
		JCheckBox newCheck = new JCheckBox("Try me");
		sample.add(newCheck);
		
		JCheckBox newCheck2 = new JCheckBox("Press");
		sample.add(newCheck2);
		
		JTextField textOne = new JTextField("Type Celebrity here (4 letters minimum)");
		textOne.setPreferredSize(new Dimension(750, 25));
		sample.add(textOne);
		
		JLabel labelOne = new JLabel("Enter the clues:", JLabel.LEFT);
		
		sample.add(labelOne);
		
		JTextField textTwo = new JTextField("Type Celebrity clue here (10 letters minimum)");
		textTwo.setPreferredSize(new Dimension(750, 25));
		sample.add(textTwo);
		
		JButton addButton = new JButton("Add current celebrity");
		addButton.setPreferredSize(new Dimension(750, 25));
		sample.add(addButton);
		
		JButton startButton = new JButton("Start celebrity game");
		startButton.setPreferredSize(new Dimension(750, 25));
		sample.add(startButton);
		
		
		
		sample.setVisible(true);
	}

}
