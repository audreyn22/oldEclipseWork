import java.util.ArrayList;

public class Logic {
	
	/*
	 * Return true if the character exists anywhere in str
	 */
	public static boolean exists(String word, String character) {
		
		/*
		 * .indexOf(String str) -> returns index where str is found
		 * 						   returns -1 if not found
		 */
 		return (word.toLowerCase()).indexOf(character.toLowerCase()) >= 0;
	}
		
	
	/* return true if the characters at i for word and current display are the same 
	 * 
	 * location("alien", "apple", 0) -> true (both chars are a)
	 * location("alien", "apple", 1) -> false (both chars are not the same at 1)
	 * 
	 * */
	public static boolean location(String word, String curr, int i) {
		//String methods to use: indexOf, substring, equals
		
		return ((word.toLowerCase()).substring(i, i + 1)).equals((curr.toLowerCase()).substring(i, i + 1));
	}
	
	/*
	 * Return true if the guess matches the word
	 */
	public static boolean guessWord(String guess, String word) {
		//to be completed
		return false;
	}

	
	/*
	 * Return a String with only the characters that are in the right
	 * place. 
	 * 
	 * @param word - the 5-letter word that is being guessed
	 * @param guess - the 5-letter guessed word
	 */
	public static String getCorrect(String word, String guess) {
		String str = "";
		String newWord = word.toLowerCase();
		String newGuess= guess.toLowerCase();
		
		for(int i = 0; i < word.length(); i++) {
			if((newGuess.substring(i, i + 1)).equals(newWord.substring(i, i + 1))) {
				str = str + newWord.substring(i, i + 1);
			}
		}
		return str;
	}
	
	/*
	 * Return the characters that are in the word, but in the
	 * wrong spots
	 */
	public static String getLetters(String word, String guess) {
		String str = "";
		String newWord = word.toLowerCase();
		String newGuess= guess.toLowerCase();

		for(int i = 0; i < guess.length(); i++) {
			if(((newWord).indexOf(newGuess.substring(i, i + 1)) >= 0) && !(newGuess.substring(i, i + 1).equals(newWord.substring(i, i + 1)))) {
				str = str + newGuess.substring(i, i + 1);

			}
		}
		return str;
	} 
	
	/*
	 * returns the characters from the guess that do not appear
	 * in the word
	 */
	public static String dne(String word, String guess) {
		String str = "";

		for(int i = 0; i < guess.length(); i++) {
			String character = guess.substring(i, i + 1);

			if((word.toLowerCase()).indexOf(character.toLowerCase()) == -1) {
				str = str + character;
			}

		}
		return str;
	}
	
	
	/*
	 * Return a random number between 0 and total where
	 * total is the total number of words in our 5-word dictionary. 
	 * The same word cannot be selected twice. 
	 * 
	 * @param list the list of indexes that have already been used
	 */
	public static int getNext(int total, String usedList, ArrayList<String> dictionary) {
		System.out.println(total+":"+usedList);
		
		//continue generating a random # between 0 and the last possible index (inclusive)
		//check if it's in the used list
		//if not, good to go
		//else generate another random number
		
		int number = -1;
		boolean newWord = false;
		while(!newWord) {
			number = (int) Math.random() * (total);
			if((usedList.indexOf(dictionary.get(number)) > 0)) {
				System.out.println(number);
				newWord = true;
			}
			
		}
		return number;
		
	}
	
	/* return true if the word is a word */
	public static boolean isWord(String guess, ArrayList<String> dictionary) {
		
		
		for(int i = 0; i < dictionary.size(); i++) {
			//grab a word from the dictionary
			
			String word = dictionary.get(i);
		
			
			if(word.equals(guess.toLowerCase())) { //found it in the dictionary at position i
				return true;
			}
		}
		return false;
	
	}

}
