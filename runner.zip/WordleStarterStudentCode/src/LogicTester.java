import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class LogicTester {

	@Test
	void testExists() {
		// Test to see if exists works correctly
		// given some input, what is the expected output and
		// did your method return the expected?
		
		//test 1 - simple case 1
		assertFalse(Logic.exists("alien", "x"));
		
		//test 2 - simple case 2
		assertTrue(Logic.exists("alien", "a"));

 		//test 3 - simple case 3
		assertTrue(Logic.exists("alien", "n"));

	
		//Hard cases or corner cases that occur less often but are the
		//majority of cases the programmers miss
		//test 4 - hard case 1
		assertTrue(Logic.exists("alien", "ALIEN"));
		
		//test 4 - hard case 2
		
		
		//test 4 - hard case 3
		
		
 	}
	
	@Test
	void testGetCorrect() {
		assertTrue(Logic.getCorrect("ALIEN", "aloft").equals("al"));
		assertTrue(Logic.getCorrect("tares", "tarts").equals("tars"));
		assertTrue(Logic.getCorrect("tares", "cares").equals("ares"));
		

	}
	
	@Test
	void testGetLetters() {
		assertTrue(Logic.getLetters("alien", "among").equals("n"));
		assertFalse(Logic.getLetters("notes", "lists").equals("lis"));
		
	}
	
	@Test
	void testDne() {
		assertFalse(Logic.dne("alien", "among").equals("amog"));
		assertTrue(Logic.dne("notes", "lists").equals("li"));
		
	}
	
	
	
	@Test
	void testLocation() {
		//write the assert statements that test the
		//logic of the location method
		
		//test something that should return true
		assertTrue(Logic.location("alien", "apple", 0));
		assertTrue(Logic.location("alien", "APPLE", 0));
	
		//test something that should return false
		assertFalse(Logic.location("alien", "apple", 1));
		assertFalse(Logic.location("alien", "apple", 2));
		assertFalse(Logic.location("alien", "apple", 3));
	}
	
	@Test
	void testGuessWord() {

	
	}
	
	
	@Test
	void testGetNext() {
		//create a dictionary
		ArrayList<String> dict = new ArrayList<String>();
		
		//add some words
		dict.add("alien");
		dict.add("poops");
		dict.add("cover");
		dict.add("river");
		dict.add("liver");
		
		String usedList = "alienpoopscoverriver";
		
		for(int i = 0; i < 5; i++) {
			//test that the next number should be at position 4
			int nextIndex = Logic.getNext(5, usedList, dict);
			
			assertTrue(nextIndex == 4);
			assertTrue(dict.get(nextIndex).equals("liver"));
		
		}
		
	}
	

	@Test
	void testIsWord() {
		//create a dictionary
		ArrayList<String> dict = new ArrayList<String>();
		
		//add some words
		dict.add("alien");
		dict.add("lunch");
		dict.add("river");
		dict.add("cover");
		
		//test #1 - check something that exists
		assertTrue(Logic.isWord("alien", dict));
		assertTrue(Logic.isWord("lunch", dict));
		
		//test #2 - check something that doesn't exist
		assertFalse(Logic.isWord("touog", dict));
		
		//test #3 - what else do we need to check?
		assertTrue(Logic.isWord("Alien", dict));
	}
	

}
