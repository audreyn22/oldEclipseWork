import java.util.Arrays;

public class Wordle {
	public static void main(String[] arg) {

		BoardGUI b = new BoardGUI();	
		System.out.println("word is " + b.word);
		
	}
	
	
}


