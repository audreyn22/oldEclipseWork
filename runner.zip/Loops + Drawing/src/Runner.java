import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Runner extends JPanel{
	
	// Practice using Loops, random #s and 
	// methods
	public void paint(Graphics g) {
		
		Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(5));
        
		 
//		//1) draw a concentric rectangle that's 10pixels from all sides of the "gray"
//		//portion of the GUI
//		g2.drawRect(10, 10, 765, 540);
//		
//		
//		//2) Draw a horizontal line to bisect the Rectangle
//		g2.drawLine(10, 270, 770, 270);
//		
//		
//		//3) Draw a vertical line to bisect the shape again
//		g2.drawLine(765/2, 10, 765/2,550 );
//		
//		
//		//4) small rectangles on top-left
//		g2.drawLine(765/4, 10, 765/4, 550/2-10);
//		
//		
//		/* 
//		 * int var = 0; 						<---- control variable
//		 * while(var < 10){ 					<---- condition to run the loop
//		 *   
//		 *   //any repeating code
//		 *   
//		 *   var++;								<---- update control variable
//		 *   
//		 * }
//		 */
//		
//		//top-left most with lines radiating from one point
//		int x1 = 20;
//		int y1 = 20;
//		int x2 = 180;
//		int y2 = 20;
//		g2.setColor(Color.red);
//		
//		//control variable for the loop
//		int counter = 9;
//		while(counter >= 0) {
//			g2.drawLine(x1,  y1,  x2,  y2);
//			y2 += 10;
//			counter --;
//		}
//	
//		// next drawing - horizontal parallel lines
//		x1 = 20;
//		y1 = 150;
//		x2 = 180;
//		y2 = 150;
//		g2.setColor(Color.blue);
//		
//		counter = 9;
//		while(counter >= 0) {
//			g2.drawLine(x1,  y1,  x2,  y2);
//			y1 += 10;
//			y2 += 10;
//			counter --;
//		}
//		
//		// next drawing - vertical circles
//		x1 = 235;
//		y1 = 15;
//		int width = 100;
//		int height = 100;
//		g2.setColor(Color.green);
//				
//		counter = 3;
//		while(counter >= 0) {
//			g2.drawOval(x1,  y1,  width, height);
//			y1 += 50;
//			counter --;
//		}
//		
//		//next drawing - 50 same size squares
//		x1 = 500;
//		y1 = 50;
//		width = 50;
//		height = 50;
//		
//		
//		counter = 49;
//		while(counter >= 0) {
//			g2.drawRect(x1, y1, width, height);
//			x1 = (int) (Math.random() * (710-400+1)) + 400;
//			y1 = (int) (Math.random() * (215-10+1)) + 10;
//			
//			int R = (int) (Math.random() * (255-10+1)) + 10;
//			int G = (int) (Math.random() * (255-5+1)) + 5;
//			int B = (int) (Math.random() * (255-10+1)) + 10;
//			
//			g2.setColor(new Color(R, G, B));
//			
//			counter --;
//		}
//		
//		//next drawing - 25 random sized circles
//		x1 = 100;
//		y1 = 300;
//		width = 50;
//		height = 50;
//				
//				
//		counter = 24;
//		while(counter >= 0) {
//			g2.drawOval(x1, y1, width, height);
//			x1 = (int) (Math.random() * (290-15+1)) + 15;
//			y1 = (int) (Math.random() * (430-290+1)) + 290;
//			width = (int) (Math.random() * (120-30+1)) + 30;
//			height = width;
//					
//			int R = (int) (Math.random() * (255-10+1)) + 10;
//			int G = (int) (Math.random() * (255-5+1)) + 5;
//			int B = (int) (Math.random() * (255-10+1)) + 10;
//					
//			g2.setColor(new Color(R, G, B));
//					
//			counter --;
//		}
//		
//		//next drawing - 100 random length lines
//		x1 = 500;
//		y1 = 300;
//		x2 = 400;
//		y2 = 550;
//						
//		counter = 99;
//		while(counter >= 0) {
//			g2.drawLine(x1, y1, x2, y2);
//			x1 = (int) (Math.random() * (770-390+1)) + 390;
//			y1 = (int) (Math.random() * (550-280+1)) + 280;
//			x2 = (int) (Math.random() * (770-390+1)) + 390;
//			y2 = (int) (Math.random() * (550-280+1)) + 280;
//							
//			int R = (int) (Math.random() * (255-10+1)) + 10;
//			int G = (int) (Math.random() * (255-5+1)) + 5;
//			int B = (int) (Math.random() * (255-10+1)) + 10;
//							
//			g2.setColor(new Color(R, G, B));
//							
//			counter --;
//		}
        
        g2.drawRect(10,  10,  1000,  640);
		
        //upper left corner
        g2.setColor(Color.blue);
        for(int x1 = 10, y1 = 10, x2 = 10, y2 = 650, counter = 0; counter < 44; counter++) {
        	g2.drawLine(x1, y1, x2, y2);
        	x1 += 15;
        	y2 -= 15;
        }
        
        //lower right corner
        g2.setColor(Color.cyan);
        for(int x1 = 1010, y1 = 10, x2 = 1010, y2 = 650, counter = 0; counter < 44; counter++) {
        	g2.drawLine(x1, y1, x2, y2);
        	x2 -= 15;
        	y1 += 15;
        }
        
      //upper right corner
        g2.setColor(Color.green);
        for(int x1 = 1010, y1 = 10, x2 = 1010, y2 = 650, counter = 0; counter < 44; counter++) {
        	g2.drawLine(x1, y1, x2, y2);
        	x1 -= 15;
        	y2 -= 15;
        }
        
      //lower left corner
        g2.setColor(Color.magenta);
        for(int x1 = 10, y1 = 10, x2 = 10, y2 = 650, counter = 0; counter < 44; counter++) {
        	g2.drawLine(x1, y1, x2, y2);
        	x2 += 15;
        	y1 += 15;
        }
	}
	
	
	
	
	public static void main(String[] arg) {
		Runner m = new Runner();
	}
	
	public Runner() {
		JFrame f = new JFrame("Method Use");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(800,600);
		f.add(this);
		f.setVisible(true);
		
	}
}
